<?php $this->load->view('site/slide')?>



<!-- <section class="l-section bg-mercury l-margin-vs l-padding-td home--selector">    <div class="l-constrained--tablet-landscape l-padding home--prod-selector"><a href="http://www.eldoradostone.com/product-selector/" class="home--cta-selector"> 


    <div class="row text-center--mobile">    
        <div class="large-4 columns"><img src="http://www.eldoradostone.com/wp-content/themes/elevator/assets/dist/img/product-rocks.png" alt="" height="261" width="399"></div> 

        <div class="large-6 columns"><h2 class="l-margin-bn">Product Selector</h2><p class="l-margin-bn text-xs">Find your perfect stone shape, and color and texture.</p></div>    <div class="large-2 columns text-center hide-on-mobile"><i class="icon-arrow-right2 text-xxl text-pinecone"></i></div></div></a>    </div></section>

<section class="l-section--bg home--video-wrap" style="background-image:url(http://www.eldoradostone.com/wp-content/uploads/2015/10/video-clip.jpg);">    <div class="card--video">        <div class="l-constrained--tablet-landscape">            <div class="row">                <div class="large-5 columns"><h2 class="text-white l-margin-bn">Invite the Beauty of <span class="font-family-secondary text-xxxl">Nature</span> in</h2>                 </div>            </div>        </div>    </div>    <div class="home--video">      <video class="home--video-bg" autoplay muted loop poster="http://www.eldoradostone.com/wp-content/uploads/2015/10/video-clip.jpg");">        <source src="http://www.eldoradostone.com/wp-content/themes/elevator/assets/src/img/a_new_homepage_video.webm" type="video/webm" />        <source src="http://www.eldoradostone.com/wp-content/themes/elevator/assets/src/img/a_new_homepage_video.mp4" type="video/mp4" />        <source src="http://www.eldoradostone.com/wp-content/themes/elevator/assets/src/img/a_new_homepage_video.ogv" type="video/ogg" />      </video>      <video id="home--video-full" controls poster="http://www.eldoradostone.com/wp-content/uploads/2015/10/video-clip.jpg");">        <source src="http://www.eldoradostone.com/wp-content/uploads/2017/10/Eldorado-Stone.Final_.HD_.-0901.webm" type="video/webm" />        <source src="http://www.eldoradostone.com/wp-content/uploads/2017/10/Eldorado-Stone.Final_.HD_.0901.mp4" type="video/mp4" />        <source src="http://www.eldoradostone.com/wp-content/uploads/2015/10/Eldorado_Stone_Final_HD_0901.ogv" type="video/ogg" />      </video>      <div class="home--video-close">      <div class="l-constrained">        <a href="#" class="text-white">            <i class="icon-cross"></i>        </a>      </div>      </div>      <a href="#" class="home--video-play hide-on-desktop">          <i class="icon-icon-play"></i>      </a>    </div>    <a href="#" class="home--video-play hide-on-mobile">        <i class="icon-icon-play"></i>    </a></section><section class="">

    
        <div class="home--product-slides">

            
                <div class="product-slide l-margin-vs l-padding-mobile-hs bg-image" style="background-image:url(http://www.eldoradostone.com/wp-content/uploads/2015/10/whitebarkv1.jpg);">
                    <a href="http://www.eldoradostone.com/types/stone/">
                        <div class="l-padding-vl l-constrained--tablet-landscape">
                            <div class="row">
                                <div class="small-11 columns">
                                    <h3 class="item-title text-white l-margin-bn h1"><strong>Stone</strong></h3>
                                </div>
                                <div class="small-1 columns hide-on-mobile">
                                    <p class="pull-right l-margin-bn"><i class="icon-arrow-right2"></i></p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div> 
                <div class="product-slide l-margin-vs l-padding-mobile-hs bg-image" style="background-image:url(http://www.eldoradostone.com/wp-content/uploads/2015/10/ironsidev1-bg.jpg);">
                    <a href="http://www.eldoradostone.com/types/brick/">
                        <div class="l-padding-vl l-constrained--tablet-landscape">
                            <div class="row">
                                <div class="small-11 columns">
                                    <h3 class="item-title text-white l-margin-bn h1"><strong>Brick</strong></h3>
                                </div>
                                <div class="small-1 columns hide-on-mobile">
                                    <p class="pull-right l-margin-bn"><i class="icon-arrow-right2"></i></p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div> 
                <div class="product-slide l-margin-vs l-padding-mobile-hs bg-image" style="background-image:url(http://www.eldoradostone.com/wp-content/uploads/2015/10/firebowlv1-bg.jpg);">
                    <a href="http://www.eldoradostone.com/types/fire-bowls/">
                        <div class="l-padding-vl l-constrained--tablet-landscape">
                            <div class="row">
                                <div class="small-11 columns">
                                    <h3 class="item-title text-white l-margin-bn h1"><strong>Fire Bowls</strong></h3>
                                </div>
                                <div class="small-1 columns hide-on-mobile">
                                    <p class="pull-right l-margin-bn"><i class="icon-arrow-right2"></i></p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div> 
                <div class="product-slide l-margin-vs l-padding-mobile-hs bg-image" style="background-image:url(http://www.eldoradostone.com/wp-content/uploads/2015/10/fireplacesurroundsv6-bg.jpg);">
                    <a href="http://www.eldoradostone.com/types/fireplaces/">
                        <div class="l-padding-vl l-constrained--tablet-landscape">
                            <div class="row">
                                <div class="small-11 columns">
                                    <h3 class="item-title text-white l-margin-bn h1"><strong>Fireplace Surrounds</strong></h3>
                                </div>
                                <div class="small-1 columns hide-on-mobile">
                                    <p class="pull-right l-margin-bn"><i class="icon-arrow-right2"></i></p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div> 
                <div class="product-slide l-margin-vs l-padding-mobile-hs bg-image" style="background-image:url(http://www.eldoradostone.com/wp-content/uploads/2015/10/outdoorv2-bg.jpg);">
                    <a href="http://www.eldoradostone.com/types/outdoor-living/">
                        <div class="l-padding-vl l-constrained--tablet-landscape">
                            <div class="row">
                                <div class="small-11 columns">
                                    <h3 class="item-title text-white l-margin-bn h1"><strong>Outdoor Living</strong></h3>
                                </div>
                                <div class="small-1 columns hide-on-mobile">
                                    <p class="pull-right l-margin-bn"><i class="icon-arrow-right2"></i></p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div> 
        </div> 
        

</section> -->

<!-- <div class="l-padding-bm bg-image l-constrained">
    <div class="special">
        <div class="row">
            <br/><br/>
            <div class="medium-12 column" style="text-align: center;" >
                <div class="medium-4 column">.</div>
                <div class="medium-4 column">
                    <h2>SPECIAL OFFERS</h2>
                </div>
                <div class="medium-4 column">.</div>
            </div> 
            <br/><br/>   

            <?php foreach($listtop as $tl):?>
            <?php 
                $name = convert_vi_to_en($tl->name); 
                $name = strtolower($name);
            ?>  

            <div class="medium-4 column">
                <div class="topdes">
                    <div class="tops">
                        <a href="<?php echo base_url('tour/view/'.$tl->id)?>">
                            <img  src="<?php echo base_url('/upload/tour/'.$tl->image_link)?>" width="455" height="59" alt="<?=$tl->name?>">

                            <h4 class="">
                                <?php if(strlen($tl->name) > 20) :
                                      echo substr($tl->name,0,15)."...";
                                ?>
                                <?php  else : ?>
                                    <?=$tl->name?>
                                <?php endif ?>
                            </h4>

                            <div class="cta-card__content"><span style="font-size:12px;"> 
                                <?php 
                                    echo date('d/m/y H:i:s',$tl->created);
                                ?>
                            </span>
                            <span style="font-size:12px;"> | <?=$tl->site_title?></span></div>

                            
                            <div class="btnn">
                                <div class="btn booktour">
                                    <span >
                                        <span>
                                            <a href="<?php echo base_url('cart/add/'.$tl->id) ?>" >BOOK TOUR</a>
                                        </span>
                                    </span>
                                </div>
                                <div class=" btn viewtour">
                                    <span>
                                        <span>
                                            <a href="<?php echo base_url('tour/view/'.$tl->id)?>" >VIEW MORE</a>
                                        </span>
                                    </span>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach ?>

        </div>
    </div>
</div> -->



<main id="mtatuong">
    <div class="row">
        <br/><br/>
        <div class="medium-12 column" style="text-align: center;" >
            
            <div class="medium-4 column medium-offset-4">
                <h2 style="font-size:font-size:35px;">SPECIAL OFFERS</h2>
            </div>
            
        </div>
    </div>
<div id="" class="background-global">
<section id="tour" class="tour">
<div class="container">
    <div>
        <div class="owl-carousel">

            <?php foreach($listtop as $tl):?>
            <?php 
                $name = convert_vi_to_en($tl->name); 
                $name = strtolower($name);
            ?>  
            
                <div class="topdes">
                    <div class="tops">
                        <a href="<?php echo base_url('tour/view/'.$tl->id)?>">
                            <img  src="<?php echo base_url('/upload/tour/'.$tl->image_link)?>" width="455" height="59" alt="<?=$tl->name?>">

                            <div class="contentt">
                                <h4 class="">
                                    <?php if(strlen($tl->name) > 20) :
                                          echo substr($tl->name,0,15)."...";
                                    ?>
                                    <?php  else : ?>
                                        <?=$tl->name?>
                                    <?php endif ?>
                                </h4>


                                <div class="cta-card__content">
                                    <p style="font-size:15px;"> 
                                        <?php 
                                            echo date('d/m/y H:i:s',$tl->created);
                                        ?>
                                    </p>
                                    <p style="font-size:15px;"> <?=$tl->site_title?></p>
                                </div>

                                
                                <div class="btnn">
                                    <div class="btn booktour">
                                        <a href="<?php echo base_url('cart/add/'.$tl->id) ?>" >BOOK NOW</a>
                                    </div>
                                    <div class="btn viewtour">
                                        
                                        <a href="<?php echo base_url('tour/view/'.$tl->id)?>" >VIEW MORE</a>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            
            <?php endforeach ?>

        </div>
    </div>
</div>
</section>

</div>

</main>



<script>
    $('.owl-carousel').owlCarousel({

        navText: ["<img src='https://saigonadventure.com/asset/frontend/images/back.png'>", "<img src='https://saigonadventure.com/asset/frontend/images/next.png'>"],
        loop: false,
        margin: 10,
        nav: true,
        autoplay: false,
        autoplayHoverPause: true,
        responsive: {
            0: { 
                items: 1
            }
            ,
            600: {
                items: 2
            },
            1000: {
                items: 3
            },
            1400: {
                items: 3
            }

        }
    });
</script>



<!-- <div class="l-padding-bm bg-image" style="background-image: url(http://www.eldoradostone.com/wp-content/uploads/2015/12/header-16.jpg);"> -->
    <div class="l-padding-bm bg-image l-constrained">
    <!-- <div class="l-constrained--tablet-landscape"> -->
        <div class="">
    <div class="row">
            <br/><br/>            
            <div class="medium-6 column columnm">
                <h2 class="cta-card__heading" style="color:#F37920;font-size:35px;">GALARY</h2>
                <div class="row">
                    <div class="medium-6 column columnm">
                        <div class="row">
                            <?php foreach($tour_more2 as $row) : ?>
                            <div class="medium-12 column columnm columnmmm">
                                <a href="<?php echo base_url('tour/view/'.$row->id)?>">
                                    <img class="cta-card__image1" src="<?php echo base_url('/upload/tour/'.$row->image_link)?>" alt="<?=$row->name?>" title="<?=$row->name?>" alt="con-cta" data-bin-shiv>
                                </a>
                            </div>
                            <?php endforeach ?>
                            
                        </div>
                    </div>

                    <div class="medium-6 column columnm">
                        <div class="row">
                            <?php foreach($tour_more as $row) : ?>
                            <div class="medium-12 column columnm columnmm">
                                <a href="<?php echo base_url('tour/view/'.$row->id)?>" title="<?=$row->name?>">
                                    <img class="cta-card__image2" src="<?php echo base_url('/upload/tour/'.$row->image_link)?>" alt="<?=$row->name?>" title="<?=$row->name?>" alt="con-cta" data-bin-shiv>
                                </a>
                                
                            </div>
                            <?php endforeach?>
                            
                        </div>
                    </div>
                </div>
            </div>




            <div class="medium-6 column">
                <h2 class="cta-card__heading" style="color: #F37920;font-size:35px;">VIDEO</h2>    
                    <iframe width="100%" height="405px" src="https://www.youtube.com/embed/3tDd7EbO8NY" frameborder="0" allowfullscreen></iframe>
            </div>
        </div>
    </div>
</div>

    