<div class="hero l-section--md l-section--bg" style="background-image:url( 'http://www.eldoradostone.com/wp-content/uploads/2015/10/header-12.jpg' );">
    <header class="hero__content l-constrained">
        <h1 class="hero__heading">
        About Us             </h1>
    </header>
</div>
<div class="l-constrained l-section--lg faux faux--primary">
    <?=$info_list->content;?>
</div>


