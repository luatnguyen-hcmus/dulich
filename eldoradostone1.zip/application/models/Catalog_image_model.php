<?php 
	Class Catalog_image_model extends MY_Model{
		var $table = 'catalog_image';
	}