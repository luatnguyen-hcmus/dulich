<?php 
	Class User_model extends MY_Model{
		var $table = 'user';
	}