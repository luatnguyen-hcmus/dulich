<?php 
	Class Review_model extends MY_Model{
		var $table = 'reviews';
	}