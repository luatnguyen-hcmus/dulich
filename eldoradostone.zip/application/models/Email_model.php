<?php 
	
	Class Email_model extends MY_Model{
		var $table = "email";
	}
?>