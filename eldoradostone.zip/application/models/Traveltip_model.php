<?php 
	Class Traveltip_model extends MY_Model{
		var $table = 'travel_tips';
	}