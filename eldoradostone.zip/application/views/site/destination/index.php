<div class="page-position content-main clearfix" data-position="content-main">
	<div class="leadercontent container lead text-center clearfix" id="leadercontent-7873">
	  	<div class="text"><div>
	  		<h2>This is your planet. Get to know it.</h2>
	  			<p>Vast, wide, bottomless, and limitless: Welcome to Earth, the universe’s #1 travel destination. There’s more to see, do, touch, smell, and taste on this wondrous little rock than we could possibly cover here, but one thing’s for sure: Wherever you’re headed, we’re already there.</p>
	  		</div>
	  	</div>
	</div>
	<div class="container">
            <?php foreach($listtop as $row) : ?>
            	<?php 
                        $name = convert_vi_to_en($row['name']); 
                        $name = strtolower($name);
                    ?>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <article class="card" style="min-height: 250px;margin-bottom: 30px; text-align: center;">
                        <div class="wrap-time-line">
                            <div class="time-line">
                                <div class="left-time clock" data-value="539217"></div>
                            </div>
                        </div>
                        <a href="<?php echo base_url($name.'-c'.$row['id_catalog'])?>" title="<?=$row['name']?>" class="featured-image" >
                            <img style ="height:200px; width:300px;" src="<?php echo base_url('/upload/catalog/'.$row['image'])?>" alt="<?=$row['name']?>" title="<?=$row['name']?>"/>

                            <div class="featured-img-inner"></div>
                        </a>
                        <div class="card-details" style="background-color: #ffab1d !important">
                            <h4 class="card-title"><a style="color: white;" href="<?php echo base_url($name.'-c'.$row['id_catalog'])?>" title="<?=$row['name']?>"><?=$row['name']?></a></h4>
                        </div>
                    </article>
                </div>
            <?php endforeach ?>
        </div>
      
</div>