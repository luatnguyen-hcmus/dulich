
<div class="sub-nav">
    <div class="navbar navbar-inverse">
        <div class="container">
            <div class="navbar-header">
                <h1 class="h1-title-d">
                    Checkout Success
                </h1>
            </div>
            <!-- Sub Nav Links -->
        </div>
    </div>
</div>

<section class="regular" style="padding-top: 4rem">
    <div class="container">
        <div class="row">
            <div class="col-lg-9">
                <p>Thank you very much for your booking. You have been done successfully. Our staff will contact you within 24 hours. Feel free to contact us for further assistance. Hotline:  +84972 050 808/+84911 411 028. Have a great day!</p>
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <div class="col-lg-3">
                    <div id="sidebar">
                        <style>
                            h4.sub-menu-left {
                                background: none;
                                font-size: 13px;
                            }

                            h4.sub-menu-left span {
                                margin-right: 5px;
                                color: #003580;
                            }
                        </style>
                        <div class="wrap-item-sidebar">
                            <a alt="Early bird SALES"><img src="/files/files/Promotion/early%20bird%20promotion.jpg" width="279px"/></a>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
    </div>
</section>