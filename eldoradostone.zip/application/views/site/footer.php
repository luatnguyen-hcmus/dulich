<div class="l-constrained">
    <div class="medium-4 columns" id="footer_nav">
        <hr class="footer-divider-1">
        <h5 style="color: #000000; font-weight: 800;">THE BEST TOUR</h5>
        <ul class="menu-horizontal row">
            <?php foreach($tour_mores as $row) : ?>
                  <li><a href="<?php echo base_url('tour/view/'.$row->id) ?>"><?=$row->name?></a></li>
            <?php endforeach ?>
        </ul>
                
    </div>
            <!--Stay Connected-->
    <div class="medium-4 columns">
          <hr class="footer-divider-2">
          <h5 style="color: #000000; font-weight: 800;">CONTACT US</h5>
          <ul>
                <p><a hre="">13 Tran Van Giap Street, Hiep Ten block, Tan Phu District, HCM City</a></p>
                <p> <i class="fas fa-phone-volume"></i>
                    <?php  foreach($more_phone_list as $mpl):?>
                        <a href="tel: <?=$mpl->phone?>"> 
                          <span><?=$mpl->phone_show?></span>
                        </a> | 
                    <?php endforeach?>
                </p>
                                     
                <p><i class="fa fa-envelope"></i>
                      <?php  foreach($email_list as $el):?>
                          <a href="mailto:<?=$el->email?>"> 
                             <span> <?=$el->email?></span>
                          </a>
                      <?php endforeach?>
                </p>
          </ul>
    </div>
    <div class="medium-4 columns">    
          <hr class="footer-divider-2">
          <h5 style="color: #000000; font-weight: 800;">TRIPADVISOR</h5>
          <i class="fab fa-tripadvisor fa-7x"></i>
          <i class="fab fa-tripadvisor-7x"></i> 
    </div>
            
</div>
