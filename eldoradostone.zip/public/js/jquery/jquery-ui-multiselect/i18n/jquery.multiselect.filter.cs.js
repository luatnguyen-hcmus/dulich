/* Czech initialisation for the jQuery UI multiselect plugin. */
/* Written by Michi (michi.m@gmail.com). */

(function ( $ ) {

$.extend($.ech.multiselectfilter.prototype.options, {
  label: "Filtrovat:",
  placeholder: "Napište výraz"
});

})( jQuery );
